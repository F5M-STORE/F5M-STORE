# TikTok Username Store

## تشغيل المشروع

```
npm install
npm run dev
```

## إعداد Stripe

أنشئ ملف `.env.local` وضع فيه:

```
NEXT_PUBLIC_STRIPE_KEY=pk_test_xxx
STRIPE_SECRET_KEY=sk_test_xxx
```
